Note that most of these models are collected from the internet.
Some of them I modified more or less, others I left unchanged.

The observation that a number of these models do generate geometry 
and/or segmentation errors or warnings show that without geometry/
segment testing it's very easy to create a less reliable model
which at first sight migth seem very usefull.

I also added a number a number of Nec models extracted from cor-
responding MiniNec based models (thanks to AC6LA). When using one 
or more of these models, be sure you perform an Average-Gain and/or
Convergence test to check the reliablility of the model to use.

In the zzEznec folder Nec representation of the EZnec 3.0 demo
files are included.
 
Furthermore in the Equations folder a number of equational models
are included (thanks to L.B. Cebik). In the *.nec input-file, you
can specify the frequency and wire diameter of interest. After this 
4nec2 will calculate the resulting antenna dimensions for you and
visualize them on the Geometry (F3) window. After Nec2/4 calcula-
tion you can inspect antenna performance.
