Directional dipole and three-element Yagi antennas to
be used as standard transmit antennas for area-coverage
or point-to-point predictions. 

As reception antennas however one should use the antennas
included in the 'Receive' folder. These type-11 antennas
are of omni-directional nature and are thus better suited
as receive antenna for area-coverage predictions. 

This because when running an area-coverage all receiving
antennas should use the same pattern not influenced by
'bearing  between transmitter and receiver location.