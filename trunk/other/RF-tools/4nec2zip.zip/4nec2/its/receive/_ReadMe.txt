'Omni'-directional antennas to be used as receiving antennas
for area-coverage (and point-to-point) predictions.

The type-11 omni-directional patterns where created using the 
default (directional) ItsHF antenna types as included in the 
'Transmit' folder. The Vertxy- and ISOxxdB.hfa antennas are
omni-directional by nature.

DIP0xx.N11	' Omni-directional 'dipole' at height = 0.xx wavelenght
YAG0xx.N11	' Omni-directional 3 element 'Yagi' at height = 0.xx wavelenght
VERTxy.HFA	' Omni-directional vertical with height=x/y wavelength
ISOxxdB.HFA	' Omni-directional constant gain (xx dB) isotrope radiator