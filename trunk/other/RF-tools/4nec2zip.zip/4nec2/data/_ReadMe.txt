Latest sunspot.txt data can be downloaded at: 

ftp://ftp.ngdc.noaa.gov/STP/SOLAR_DATA/SUNSPOT_NUMBERS/sunspot.predict

Save the data in this file under sunspot.txt in the..\4nec2\data folder.
