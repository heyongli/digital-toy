[version 5.6.6] Short explanation how to create/install the 4nec2(X) environment
	        (Windows-95/98/ME/NT/2000/XP)

IMPORTANT:	The 5.3 and later versions consist of two supplementary packages.

		1) The default 4nec2 package for 'normal' usage on standard
		   and older computer systems.
		2) An extended 4nec2X supplement which adds real-time 3D viewing
		   usable on the modern computer systems
		
	       --> For real-time 3D usage and in case of problems be sure
	           you red the sections next to the below installation steps.


To install the 4nec2 or 4nec2X program, follow the below steps.
---------------------------------------------------------------

1) Extract the setup_4nec2.exe program from the 4nec2v53.zip file and copy or move
   it into a temporary folder.

2) Double click the setup_4nec2.exe program. This wil automatically install 4nec2.exe
   and other required files used by the 4nec2 default package.

3) If real-time 3D rendering is required, extract the setup_4nec2X.exe program from 
   the 4nec2X53.zip file and move or copy it into a temporary folder.

4) Double click the setupX.exe program. This wil automatically add the 4nec2X.exe
   program and other extensions to the your ../4nec2/exe folder.

5) BE SURE YOU SPECIFIED THE SAME FOLDER WITH THE 4nec2X INSTALL (e.g. C:\4nec2)
   AS SPECIFIED WITH THE DEFAULT INSTALL.

6) Double click any *.nec file, select 'Other' in the 'Open with' window and browse
   for your ..\4nec2\exe\4nec2.exe program to automatically start 4nec2 when
   double-clicking any *.nec file.

7) When using 4nec2 together with a licensed Nec-4 engine instead of the default 
   public-domain Nec-2 engines, read below item C) first.

8) When using 4nec2X together with Multinec, please rename the file 4nec2X.exe to
   4nec2.exe

9) In case of difficulties running the 4nec2(X) program, please read the below notes.


*****************************************************************************************


!! ==>	With version 5.3 and later one can use hardware-acceleration provided by your
	graphics-card to speed-up the 3D visualization and view the geometry structure
	in real-time 3D. To use this provision you must run the 4nec2X extended version 
	executable.  This 4nec2X executable is available through the 4nec2X*.zip 
	file. 

	Although this real-time rendering is available for all systems ranging from win-
	dows-95 to the latest -XP systems it is recommended to use it only on systems
	which incorporate one of the more modern graphics-cards. This because the older 
	cards might not be compatible with the graphics-software used by 4nec2X.

	If this is the fact you probably have to stick on the 4nec2 standard version,
	but before deciding to do so, please check if your desktop color-setting
	is set to 256 colors. If so, please change to 16 bit colors and try again.

	To be able to run the 4nec2X eXtended version, the microsoft DirectX software
	installed on your system (used for 3D rendering) must be Version 8.0 or later. 
	The check your current version, use 'DirectX-version' on the 4nec2 'Help' menu
	or run the GetDxVersion.exe program, located in the ..\4nec2\EXE folder.

	If DirectX version 7.x or before is installed, please download the latest 
	DirectX version from www.microsoft.com and install this on your system. Most 
	modern computer-systems (2001 and up) should have an 8.0 or later version 
	already available.
	Note that, according the microsoft website, after installation of DirectX8.1
	or later this version can not be removed anymore, so read carefully what is 
	written about this on the microsoft DirectX download-page

	If you are still experiencing problems, be sure you are using the latest 
	drivers belonging to you graphics-card. Consult the manufacturers website 
	to check for this.

	The DirectX based 4nec2 version does not run on windows-NT, because windows-
	NT does not allow the installation of the DirectX package.

	You can get additional DirectX diagnostic information by running/opening the 
	DXDIAG tool from 'Start->Run' on the windows task-bar.


FURTHER IMPORTANT GENERAL NOTES:

	a) On windows Vista the help system used for W-95 up to W-XP is not supported
	   anymore. If help is needed, please download 'winhelp32 for Vista' from the
	   Microsoft website at
	   " http://www.microsoft.com/downloads/details.aspx?displaylang=en&familyid=
           6ebcfad9-d3f5-4365-8070-334cd175d4bb " or visit my Website for the link.

	b) If the 4nec2 help file can not be found after pressing the <F1> key, browse
	   to the ...\4nec2\exe folder and select the 4nec2.hlp file.  

	c) When key's F6 (Edit input-file), F8 (View output file) and/or 'Help->Nec2 user-
	   manual'  won't work you probably have a different path to the Notepad, Wordpad
	   or Word text editor's. You may customize these by changing the folder settings
	   in the 'Settings->Folders->xxx editor' menu on the 'Main (F2)' window. 
	   To locate your Notepad, Wordpad or Word text editor executables: NOTEPAD.EXE, 
	   WORDPAD.EXE or WINWORD.EXE use: 'Start->find->files or folders' on your
	   windows task-bar.

	d) When using 4nec2 with a Nec-4 engine it is required to copy a number of Nec4 
	   engine-files from your NEC4 CD into the ..\4nec2\exe folder, these are:
	   nec4d600.exe, nec4d1200.exe, nec4d2000.exe, nec4d3600.exe and nec4d7500.exe

	   After this, click 'Settings->NEC-engine->Nec4d*.exe' on the 'Main' window
	   to let 4nec2 know it must use the Nec4d*.exe executable instead of the default
           nec2d(XS)*.exe files to calculate results.

	   Place your Nec4UsersMan.pdf file in the ..\4nec2 folder for easy access
	   through the 4nec2 Help function.

	   Note however that Nec-4 is a licensed product, so no Nec4 engines are included
	   in the 4nec2 package. A Nec-4 license and corresponding executable files can 
	   be purchased at the Lawrence Livermore National Laboratory. (LLN)

	   Due to the fact that the Nec4d*.exe files as delivered on the LLN-CD are not built
	   with command-line argument and/or input(file) redirection support the starting and 
	   file-name interfacing between 4nec2 and the Nec4d*.exe engines is somewhat cumber-
	   some. You could contact Jerry Burke at LLN to see if he is willing to create a 
	   special Nec4d*.exe file including command-line support for you or you could compile
	   your own Nec4d*.exe file using the freeware G77 fortran-compiler. If so, let me
	   know and I will include the command-line support for the Nec-4 engine into 4nec2. 

	   Because ot the above it's possible that after a system (re)boot, the first time
	   the Nec4d engine is called an exception is generated due to a time-out when loading
	   the Nec4d program file. You can avoid thsi by doing a single manual start of the 
	   Nec4d*.exe executable, so it's loaded in your system cache. 

	   Note also that the author of 4nec2 did not have the possibility to test all
	   differences between Nec2 and Nec4 himself because of above license issues, so
	   if you are using Nec4 and you think you found a Nec4 related problem, please
	   let me know. 

	e) The Nec-2 calculations for the 4nec2 program are handled by so called Nec-2
	   engines. In this package two different types of engines are available: 
	   1) the original nec2d engine by Jos Bergevoet, and 2) the nec2dXS engines. 
	   Both engines have their (dis)advantages. 

	   Both nec-2 engine uses different nec2d(XS)***.exe's for increasing number of 
	   segments. With version 5.0 or later the required executable is automatically
	   selected by 4nec2 according the total number of segments specified in your 
	   *.nec input-file.
	   
	   The largest number of segments you can run on your system depends on the 'big-
	   gest' executable that can be run on your system. For the original nec2d engine
	   this depends on the amount of physical/RAM memory available on your computer. 
	   If RAM is not enough a "not enough memory-error" is generated, and you will 
	   have to lower the number of segmetns in your modell. Note however, that when
	   a certain executable should just run (see 4nec2 help for more info), but there
	   is too much memory in use by Windows or other programms, more obscure errors 
	   like "Error opening input file" could be generated.

	   For the original nec2d engine, the 'smallest' exe that can be used also seems
	   related to the amount of  RAM. When using a 'simple' nec input file with few 
	   segments in combination with a 'small' exe, but with a big amount of RAM, a 
	   message "Program requires MS-DOS mode,...." might be displayed. If this is the
	   case, increase the number of segments in the 'nr of segments' setting, till 
	   the message no longer appears. On the other hand, don't specify a far too big 
	   setting, because this will decrease calculating performance.

	   The largest number of segments that can be run on your system with the more
	   recent Nec2dXS engine depends on the amount of time you have. When the amount
	   of RAM is not enough to do the calculations additional disk storage (virtual-
	   memory) is used by the nec2dXS engine. However this is much, much slower than
	   when using physical/RAM memory

	   Nec2d (dis)advantages:

	   + Faster when using the Optimizer/Evaluator.
	   + For 'small' exe's faster than for 'big' ones (same nr-seg)
	   + Especially suited for the 'older' windows-95/98/NT systems.
	   - Reduced precision when using SomNec ground inside frequency loop.
	   - Does not run on Windows-XP or Windows-2000/2003.
	   - Can not use temporary disk-storage to increase max number of segments.

	   Nec2dXS (dis)advantages:

	   + Runs on all Windows systems.
	   + Max nr of EX and TL cards increased from 30 to 99 (Version 5.0)
	   + Maximum precision when using SomNec ground with frequency loop.
	   + No separate executable required for SomNec ground calculations.
	   - Due to start-up time, slower when using Optimizer/Evaluator.
	   (+ Uses additional disk storage if on-board RAM memory is insufficient.)
	   
	   Nec2d executables for 256 and 512 and Nec2dXS exe's for 500 and 1500 segments
	   are included in the 4nec2 package. 
	   Free executables for more segments can be found at the "Unofficial Nec ar-
	   chives" at "www.si-list.org/swindex2.html". After download place these exe-
	   cutables in your ..\4nec2\EXE folder.

	   Note: from verion 5.3.4 and later two different Nec2dXS packages are available:
	   Nec2dXS_VM.zip (djgpp version, 418 kb), capable of using virtual(disk) memory 
	   and Nec2dXS_FB.zip (mingw version, 333 kb) which is generally faster (especially
           for lower segment counts), but not capable or running virtual memory. For users
	   running large models, the _VM package is recomended. For users using one or 
	   both optimizers the _FB package is recomended.

	f) On Windows-XP and -2000 systems with recent (service pack 2) updates installed 
	   it is possible following error is generated when the Nec-2 engine is started:
	   "The system file is not suitable for running MS-DOS and Microsoft Windows 
	   applications. Choose 'Close' to terminate the application."
	   To solve this problem, please consult the '_Run_DOS_Problem.txt' file included
	   in the package

	   This problem seems only related to the Nec2dXS.exe files from the Nec2dXS_FB.zip
	   package, so as an alternative you could use the Nec2dXS.exe files from the
	   Nec2dXS_VM.zip package. (available at "www.si-list.org/swindex2.html")

	g) Some windows-2000 and -XP users reported problems related to the Nec-2 engine
	   when the package is installed under C:\program files. If this is the case, it 
	   could be wise to select a folder-name and/or nec-file names without embedded
	   spaces. 

	h) When using none-default desktop (color) settings, it is possible that one or
	   more text-boxes and/or windows are not visible or correctly painted. When 
	   using a none-default setting, please temporary switch back to the default 
	   desktop (color) settings to check if, for both settings, the same information
	   is visible.
	   On windows-XP, with its large default Font-size it is possible lower part of the
	   window is cut-off. If required you can resize or re-position any 4nec2 window. 
	   These settings are automatically save and re-used the next time 4nec2 is started.
	   
	i) See 4nec2.hlp for more information about 4nec2 functionality. 4nec2 help in 
	   printable form is included in the 4nec2.rtf file. You can print this file for
	   comfortable reading. Also the file _GetStarted.txt might help you find your
	   way through the 4nec2 package.
	
	j) The Nec-2 user manual can be found at "www.nec2.org". Select the word document 
	   and place this file as 'NEC2.DOC' in your '..\4nec2' folder for viewing with 
	   'Help -> nec-2 manual'.

	k) When you try to read-in an incomplete *.out output file (caused by nec2d errors
	   or because calculation was not yet finished), it is possible that a 4NEC2 program 
	   error is generated because of the incomplete data. To solve the problem, Remove 
	   the '*.out' file from the '\OUT' folder and try again.

	l) A suggestion from a user having difficulties: (see also item [m] below)

	   > Just an advice to all who are having problems with the 4NEC2 program.
	   > If, when you try to generate the output, the only thing you see is a
	   > flashing DOS window, then nothing else happens, this is the cure :
	   >
	   > - locate in the EXE folder of the program a DOS shortcut named 4NEC2 
	   > without extensions
	   > - open its properties (by clicking on it with right mouse-button)
	   > - select the "Memory" tab
	   > - in the "Initial Environment" combo box, make the choice "4096" instead of 
	   > the default "Auto"
	   > - click Apply, then Ok
	   >
	   > Try to execute the program again, now it should work ok.

	m) Due to the DOS based nature of the original nec2 engine, filenames are
	   internally truncated to 8 characters. Normally this should work fine, however
	   if white-spaces are embedded in your file-name the truncation might fail, so
	   don't use white-spaces in your file-names.
	   Furthermore the maximum file-name length for *.gnd files is restricted to 8 
	   characters. When you run a lot of different (high)freq/cond/diel settings, it
	   is occasionally possible you get an "Error on groundfile" message. It this is
	   the case, remove all *.gnd files and try again.

	n) When no *.out output is generated by your Nec-2/4 engine (check the \OUT folder), 
	   please set the "Wait for DOS-box option" in 'Settings->Other settings' on the
	   "Main" form, to see what error message is logged. 
	   Furthermore you could temporary remove the "@echo off" line in the 4nec2.bat 
	   file in the \EXE folder, by adding the characters "rem" before it. This should 
	   deliver even more logging.

	o) If an "out of environment space" error is generated, please re-read item k) or
	   consult the '_Out_of_env_space.txt' file included in the package

	p) If you enjoy this software, you could send me a note and tell me how you did hear
	   about 4nec2. This way I can also inform you when new versions are available.

	q) If you should experience any problems installing and/or running the 4nec2 program,
	   or for suggestions, questions or remarks, please contact me at:     
									     4nec2@gmx.net

	   TO AVOID DELETING YOUR MAIL AS SPAM, PLEASE INCLUDE "4NEC2 MODELLER" AS THE
	   SUBJECT !!

*****************************************************************************************

For latest versions, changes and/or bugfixes see the ReleaseNotes on my website:

	http://home.ict.nl/~arivoors/


