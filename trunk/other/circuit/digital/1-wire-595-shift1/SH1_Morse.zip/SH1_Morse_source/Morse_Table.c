// This is the table of Morse code values to be used in SH1_Morse.c
// each Morse character is defined like this; ccccc nnn
// where ccccc is the morse dots, and nnn is the length in morse dots.
// so "P" = 'dit dah dah dit' = 01100 100   

const unsigned char MT[36] = {
 0b01000010,  // a    MT[0]
 0b10000100,  // b
 0b10100100,  // c
 0b10000011,  // d
 0b00000001,  // e
 0b00100100,  // f
 0b11000011,  // g
 0b00000100,  // h
 0b00000010,  // i
 0b01110100,  // j
 0b10100011,  // k
 0b01000100,  // l
 0b11000010,  // m
 0b10000010,  // n
 0b11100011,  // o
 0b01100100,  // p
 0b11010100,  // q
 0b01000011,  // r
 0b00000011,  // s
 0b10000001,  // t
 0b00100011,  // u
 0b00010100,  // v
 0b01100011,  // w
 0b10010100,  // x
 0b10110100,  // y
 0b11000100,  // z

 0b11111101,  // 0    MT[26]
 0b01111101,  // 1
 0b00111101,  // 2
 0b00011101,  // 3
 0b00001101,  // 4
 0b00000101,  // 5
 0b10000101,  // 6
 0b11000101,  // 7
 0b11100101,  // 8
 0b11110101,  // 9
 };

#define NUM_WORDS 26    // is number of words in the list below
const unsigned char *Words = {
 "hel."    
 "can."
 "who." 
 "zer."
 "fox." 

 "lon."
 "rig."
 "cal." 
 "pen."
 "wal."

 "tra."
 "yet."
 "rea."
 "mov."
 "sid."
 
 "ble."
 "kou."
 "bus."
 "cod."
 "dip."
 
 "met."
 "jut."
 "fie."
 "taq." 
 "caa."
 
 "hee."

 
 };






