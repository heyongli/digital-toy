#!/bin/bash  


message="`printf "$1"`"

length=`echo ${#message}`
#add 1 to length for newline at end
length=`expr $length + 1` 
#fix newline at end of string... (they get stripped if no character comes afterwards)
message=$message`printf '\n-'`

for ((i = 0; ${#message} <= 200; i++))
do
message=$message`printf '-'`
done

#convert to hex
length=`printf '%x' $length`

delay=`printf '%x' $2`
delayLast=`echo $delay | sed -n '0,/.*\([0-9a-f][0-9a-f]$\).*/s//\1/p'`

delayFirst=`echo $delay | sed "s/$delayLast//"`


eeprom="\x""$length""$message""\x$delayFirst\x$delayLast"
#"$delay"
echo $eeprom
printf "$eeprom" > ee_tmp.bin
avr-objcopy -I binary -O ihex ee_tmp.bin main.eep
avrdude -p M48 -c usbtiny -U eeprom:w:main.eep
