The firmware source is located in the "src" folder, with a pre-compiled binary for the ATMEGA48A. The makefile can be easily edited to be used for other (ATMEGA168 or ATMEGA328) microcontrollers.

To change the message, simply use eeprom.sh (in a bash shell) with the arguments MESSAGE TIME (in single quotes) 
ie.
./eeprom.sh '  Use  \n  the  \n Force!\n*_uPOV_*' 1600

The eagle cad files are located in the eagle folder. 
