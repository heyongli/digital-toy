Shrediquette - a tricopter by William Thielicke
Published under CC Attribution-Noncommercial-Share Alike 3.0 Germany
http://shrediquette.blogspot.com