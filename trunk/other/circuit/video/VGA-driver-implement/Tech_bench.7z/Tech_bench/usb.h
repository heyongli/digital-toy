/*
 * USB.H
 *
 *
 * CH341 USB->MEM Driver for OVGA
 * Designed By XiaomaGee 2009.5.21
 *
 *
 */
#ifndef __usb_h__
#define __usb_h__

#include <windows.h>


//----------typedef-------------//


typedef BOOL (CALLBACK* FP1_FT)();
typedef unsigned long int  (CALLBACK* FP2_FT)(); 
typedef void * (CALLBACK * FP3_FT)();



typedef struct{
	int(* initialize)(void);
	int(* open)(unsigned long int);
	int(* close)(unsigned long int);
	int(* write0)(unsigned long int /* DEVICE_ID */,void * /* buffer */,unsigned long * /* len */);
	int(* write1)(unsigned long int /* DEVICE_ID */,void * /* buffer */,unsigned long * /* len */);	
	int(* read0)(unsigned long int /* DEVICE_ID */,void * /* buffer */,unsigned long * /*len */);
	unsigned long int(* get_driver_ver)(unsigned long int /* DEVICE_ID */);
	void *(* get_device_name)(unsigned long int /* DEVICE_ID */);
}USB_T;

extern USB_T usb;
	


#endif /* __usb_h__ */
