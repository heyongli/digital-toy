/*
 * main.C
 *
 * OVGA Test bench main file.
 * Designed By XiaomaGee 2009.5.21
 *
 *
 */

//--------------include files----------------//

#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <string.h>
#include "usb.h"

#define NO_CHANGE 0
#define ONLY_R  1
#define ONLY_G  2
#define ONLY_B  3
#define RGB2GRAY 4
#define REVERSE  5
#define NOT_DISPLAY 6

const char * attribute[]={
	"NO_CHANGE",
	"ONLY_R",
	"ONLY_G",
	"ONLY_B",
	"RGB2GRAY", 
	"REVERSE", 
	"NOT_DISPLAY" 
}; 
union{
	unsigned char value;
	struct {
		unsigned char bit0:1;
		unsigned char bit1:1;
		unsigned char bit2:1; 
		unsigned char bit3:1; 
		unsigned char attrib:3;
		unsigned char bit7:1;
	}bits;
}set; 


//--------------function prototype----------------//

int fill_rgb(unsigned char *,int len ,unsigned char ,unsigned char,unsigned char);
int clear_address(void);
int download(char * /* path */);
int fill(unsigned char /* red */,unsigned char /* green */,unsigned char /* blue */);
int set_attrib(unsigned char /* attrib */);
int close_app(void);

//-------------------function--------------------//
/*
 * clear_address
 *
 *
 *
 */
int clear_address(void)
{
	unsigned long int i, len;

	set.bits.bit1=1;
	len=1;
	usb.write1(0,&set.value,&len);

	set.bits.bit1=0;
	len=1;
	usb.write1(0,&set.value,&len);

	return 0;
}

/*
 * download image
 *
 *
 *
 */
int download(char *path)
{
	unsigned long int len=0;
	FILE * fp; 
	char *p;
	char * q;
	int i,j;

	clear_address();
	fp=fopen(path,"r");
	if(fp==NULL){
		printf("Con't find files.\r\n");

		return 0;
	}

	q=malloc(800*600*2);
	p=q;

	fread(p,sizeof(char),800*600*2,fp);

	len=4096;

	printf("\r\n\r\nDownloading img");

	for(i=0;i<(800*600*2)/4096;i++) {
		usb.write0(0,p,&len);
		p+=4096;
		printf(".");

	}

	len=(800*600*2)%4096;
	usb.write0(0,p,&len);

	printf("ok\r\n");

	free(q);

	fclose(fp);

}
/*
 * fill_rgb
 * 
 *
 *
 */

int fill_rgb(unsigned char * buffer,int len,unsigned char r,unsigned char g,unsigned char b)  
{
	int i;

	for(i=0;i<len;i++){
		buffer[i*2]=(b>>3)|(g<<5);
		buffer[i*2+1]=(r&0xf8)|(g>>5);
	}

	return 0;
}

/*
 * fill
 *
 *
 *
 */
int fill(unsigned char r,unsigned char g,unsigned char b)
{
	unsigned long int len=0;
	char *p;
	char * q;
	int i;

	clear_address();

	q=malloc(4096*2);

	p=q;

	fill_rgb(p,4096,r,g,b);

	len=4096;

	printf("\r\n\r\nfilling");

	for(i=0;i<(800*600*2)/4096;i++) {
		usb.write0(0,p,&len);
		printf(".");

	}

	len=(800*600*2)%4096;
	usb.write0(0,p,&len);

	printf("ok\r\n");

	free(q);

	return 0;
}

/*
 * set_attrib
 *
 *
 *
 */
int set_attrib(unsigned char attr)
{
	unsigned long int len;

	set.bits.attrib=attr;
	len=1;
	usb.write1(0,&set.value,&len);


	return 0;
}

/*
 * init program
 *
 *
 *
 */
int init(void)
{
	unsigned char buffer[1000];
	unsigned long int len=0;
	char *p=buffer;

	usb.initialize();

	if(usb.open(0)==-1){
		printf("Can not open device!\nProgram quit.\n");
		return 0;
	}
	printf("Open USB->PAR device...\n");

	p=usb.get_device_name(0);

	printf(p);
	printf("\n");

	set.value=0;
}

/*
 * close_app
 *
 *
 *
 */
int close_app(void)
{
	printf("closing usb device......\n");
	usb.close(0);
	printf("program quit.\n");
	return 0;

}   

/*
 * main
 * 
 *
 *
 */

int main(int argc, char *argv[])
{
	unsigned char r,g,b;
	char *p;

	int i;

	if (argv[1] == NULL) {
		printf("Usage: ovga [--help] [--version] [--fill] [--download] [--set]\n");
		return 0;
	}else if (strcmp("--help",argv[1])==0){
		printf("\nUsage: ovga [--help] [--version] [--fill] [--download] [--set]\n\n\n\
1. fill: fill RGB color to screen.\n\t e.g. ovga --fill 128,25,22;\n\n\
2. download: download image to screen.\n\t e.g. ovga --download a.bin;\n\n\
3. set: set display attribute.\n\tparameter:\
\n\tNO_CHANGE,\n\tONLY_R,\n\tONLY_G,\n\tONLY_B,\n\tREVERSE,\n\tRGB2GRAY,\n\tNOT_DISPLAY;\n\
\te.g. ovga --set ONLY_B.\n");

		return 0;
	}else if(strcmp("--version",argv[1])== 0){
		printf("\nOvga,Open VGA project by OpenSourceHardware.(http://www.oshbbs.com)\n\nVersion: 0.01 / 2009.6.28.\n\nBy XiaomaGee. XiaomaGee@gmail.com.\n");
		return 0;
	} else if(strcmp("--fill",argv[1])==0){
		r=atoi(argv[2]);

		p=strchr(argv[2],',');

		if(p==NULL)return 0;
		p++;
		g=atoi(p);

		p=strchr(p,',');
		if(p==NULL)return 0;
		p++;
		b=atoi(p);

		init();
		fill(r,g,b);
		close_app();

		return 0;
	}else if (strcmp("--download",argv[1]) == 0) {

		init();
		download(argv[2]);
		close_app();

		return 0;
	}else if(strcmp("--set",argv[1]) ==0) {
		for(i=0;i<sizeof(attribute)/sizeof(char *);i++)
			if(strcmp(attribute[i],argv[2])==0)goto aa;

		printf("parameter error!");
		return 0;

aa:		init();
		set_attrib(i);
		close_app();

		return 0;
	}else {
		printf("Usage: ovga [--help] [--version] [--fill] [--download] [--set]\n");
		return 0;
	}
}



