/*
 * USB.C
 *
 * CH341A Driver For OVGA
 * Designed By XiaomaGee 2009.5.21
 *
 *
 */

//--------------include files----------------//
#include <stdio.h>
#include <stdlib.h>
#include "usb.h"

//--------------function prototype----------------//

FP1_FT ch341_open,ch341_get_descr,ch341_close,ch341_write0,ch341_write1,ch341_read;
FP2_FT ch341_get_driver_ver;
FP3_FT ch341_get_device_name;
 
static int initialize_ch341(void);
static int open(unsigned long int);
static int close(unsigned long int);
static int write0(unsigned long int,void *,unsigned long int *);
static int write1(unsigned long int,void *,unsigned long int *);
static int read0(unsigned long int,void *,unsigned long int *);
static unsigned long int get_driver_ver(unsigned long int);
static void * get_device_name(unsigned long int);


//--------------varitable-----------------//
HMODULE ch341_handle;

USB_T usb={
    .initialize=initialize_ch341,
    .open=open,
	.close=close,
	.write0=write0,
	.write1=write1,
	.read0=read0,
	.get_driver_ver=get_driver_ver,
	.get_device_name=get_device_name 
};

//---------------function------------------//
/*
 * open
 * 
 *
 *
 */

static int open(unsigned long int id)
{
       return ch341_open(id);
}

/*
 * close
 * 
 *
 *
 */
static int close(unsigned long int id)
{
       int i;
       
        i=ch341_close(id);
        FreeLibrary(ch341_handle);
       
        return i;
       
}
/*
 * write0
 * 
 *
 *
 */

static int write0(unsigned long int id,void * buffer,unsigned long int * len)
{
       return ch341_write0(id,buffer,len);
}
/*
 * write1
 * 
 *
 *
 */

static int write1(unsigned long int id,void * buffer,unsigned long int * len)
{
       return ch341_write1(id,buffer,len);
}
/*
 * read0
 * 
 *
 *
 */

static int read0(unsigned long int id,void * buffer,unsigned long int * len)
{
       return ch341_read(id,buffer,len);
}
/*
 * get_driver_ver
 * 
 *
 *
 */

static unsigned long int get_driver_ver(unsigned long int id)
{
       return ch341_get_driver_ver(id);
}
/*
 * get_device_name
 * 
 *
 *
 */

static void * get_device_name(unsigned long int id)
{
       return ch341_get_device_name(id);
}


/*
 * initialize
 * 
 *
 *
 */


static int initialize_ch341(void)
{
   
  ch341_handle=LoadLibrary("CH341DLL.DLL");
  
  ch341_open=GetProcAddress(ch341_handle,"CH341OpenDevice");
  ch341_close=GetProcAddress(ch341_handle,"CH341CloseDevice");
  ch341_get_descr=GetProcAddress(ch341_handle,"CH341GetDeviceDescr");
  ch341_get_device_name=(FP3_FT)GetProcAddress(ch341_handle,"CH341GetDeviceName");
  ch341_get_driver_ver=(FP2_FT)GetProcAddress(ch341_handle,"CH341GetDrvVersion");

  ch341_write0=GetProcAddress(ch341_handle,"CH341MemWriteAddr0");
  ch341_write1=GetProcAddress(ch341_handle,"CH341MemWriteAddr1");
  ch341_read=GetProcAddress(ch341_handle,"CH341MemReadAddr0");

  return 0;
}

