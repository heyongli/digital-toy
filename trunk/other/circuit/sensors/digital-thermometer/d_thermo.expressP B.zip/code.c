#include <REGX52.h> 
#include <math.h>
unsigned char bcd[10],segment_counter,display_period,tst_number,bit8,bit9;
unsigned char dig[4];
float conversion_factor,constant;
float temperature;
bit done;
delay(y){
unsigned int i;
	for(i=0;i<y;i++){;}
}


setup_timers(){
EA = 1;
TMOD = 0X22;  
ET0 = 1; //Enable the Timer/counter 0 interrupt
TR0 = 1; //Enable Timer/counter 0 to count
ET1 = 0; //Enable the Timer/counter 1 interrupt
TR1 = 0; //Enable Timer/counter 1 to count
TH0 = 0;
}
void int_to_digits(unsigned long number){ 
float itd_a,itd_b;
number = number * 10;
itd_a = number / 10.0;
dig[0] = floor((modf(itd_a,&itd_b)* 10)+0.5);
itd_a = itd_b / 10.0;
dig[1] = floor((modf(itd_a,&itd_b)* 10)+0.5);
itd_a = itd_b / 10.0;
dig[2] = floor((modf(itd_a,&itd_b)* 10)+0.5);
itd_a = itd_b / 10.0;
dig[3] = floor((modf(itd_a,&itd_b)* 10)+0.5);
}

display_sequence() interrupt 1{
	display_period++;
	if (display_period > 15){
		display_period = 0;
		segment_counter++;
		if (segment_counter > 2) segment_counter = 0;
		
		switch(segment_counter){
		case 0:
			P1 = 255;
			P1_2 = 0;
			P0 = bcd[dig[segment_counter]];
			break;
		case 1:
			P1 = 255;
			P1_3 = 0;
			P0 = bcd[dig[segment_counter]]-128;
			break;
		case 2:
			P1 = 255;
			P1_4 = 0;
			P0 = bcd[dig[segment_counter]];
			break;
		}
		
	}
}
measure_temperature(){
	done = 0;
	P3_0 = 0;
	P3_1 = 0;
	P3_7 = 1;
	P2 = 0;
	delay(100);
	while (P2 < 255){
	P2++;
	delay(100);
	if (P3_7 == 1){
	done = 1;
	break;
	}
	}

	if (done == 0){
	P3_0 = 1;
	P3_1 = 0;
	P3_7 = 1;
	P2 = 0;
	while (P2 < 255){
	P2++;
	delay(100);
	if (P3_7 == 1){
	done = 1;
	break;
	}
	}
	}

	if (done == 0){
	P3_0 = 0;
	P3_1 = 1;
	P3_7 = 1;
	P2 = 0;
	while (P2 < 255){
	P2++;
	delay(100);
	if (P3_7 == 1){
	done = 1;
	break;
	}
	}
	}

	if (done == 0){
	P3_0 = 1;
	P3_1 = 1;
	P3_7 = 1;
	P2 = 0;
	while (P2 < 255){
	P2++;
	delay(100);
	if (P3_7 == 1){
	done = 1;
	break;
	}
	}
	}
	if (done == 1){ 
	bit8 = P3_0;
	bit9 = P3_1;
	temperature = ((P2 + (bit8 * 256) + (bit9 * 512))*conversion_factor)+constant;
	}
}
void main(){
	setup_timers();
	conversion_factor = 28/390.0;
	constant = 2;

	bcd[0] = 192;
	bcd[1] = 249;
	bcd[2] = 164;
	bcd[3] = 176;
	bcd[4] = 153;
	bcd[5] = 146;
	bcd[6] = 130;
	bcd[7] = 248;
	bcd[8] = 128;
	bcd[9] = 144;

	while(1){
		measure_temperature();
		int_to_digits(temperature);
	}
}