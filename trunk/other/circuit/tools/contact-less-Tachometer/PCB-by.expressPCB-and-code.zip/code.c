#include <REGX51.h> 
#include <math.h>

unsigned int clk_tmp,clk_tmp2,clk_sec,clk_sec2,ex_pulses,rps,rps_tmp,temp,rps_avg,rps_max;
unsigned int rps_his[5];
char a,b,c,d,e,ani;
unsigned char count1,count2,scale;
unsigned char scale = 4;
unsigned char bcd[10];
delay(y){
unsigned int i;
	for(i=0;i<y;i++){;}
}

ena(){
P2_7 = 1;
delay (5);
P2_7 = 0;
}

ini_lcd(){
P1_1 = 0;	 
P2_7 = 0; //transfering instructions
P2_6 = 0;
P0 = 56;  //function set
ena();
P0 = 56;  //function set
ena();
P0 = 12; // display on, cursor on, blink on
ena();
P0 = 1;	  //clr display
ena(); 
P0 = 6;	//entry mode set
ena();
//enable on 2_6
//RS on 2_7
P2_6 = 1;   // ready to transfere diplay data
}

locate(pos){
P2_6 = 0; //transfering instructions
P0 = pos; // change DDRAM adress
ena(); 	
P2_6 = 1;   // ready to transfere diplay data
}

line_2(){//go to botom line
locate(192);
}

line_1(){//go to botom line
locate(128);
} 


lcd_send(chr){
P0 = chr;
ena();
}

lcd_send_slow(chr){
delay(1500);
P0 = chr;
ena();
} 

lcd_send_num(num){
 if (num == 0){
 lcd_send (48);
 }else if(num == 1){
lcd_send (49);
 }else if(num == 2){
lcd_send (50);
 }else if(num == 3){
lcd_send (51);
 }else if(num == 4){
lcd_send (52);
 }else if(num == 5){
lcd_send (53);
 }else if(num == 6){
lcd_send (54);
 }else if(num == 7){
lcd_send (55);
 }else if(num == 8){
 lcd_send (56);
 }else if(num == 9){
lcd_send (57);
}
}

setup_interrupts(){
EA = 1;
EX0 = 0;
EX1 = 0;
ET0 = 1; //set the Timer/counter 0
TR0 = 1; //Enable Timer/counter 0 to count
TMOD = 0X25;  //counter 0 in mode 1 (16 bit counter)  , timer 1 in mode 2 (auto reload from TH1
TL0 = 0; //empty the counting registers
TH0	= 0; //empty the counting registers
TH1 = 0; //start counter from 0
ET1 = 1; //enable timer 1
TR1 = 1; //Enable Timer/counter 1 to count
PT0 = 1;
PT1 = 0;
}
void int_to_digits(unsigned int number){ //store the 5 digits of an integer number in the variable a,b,c,d,e
float itd_a,itd_b;
itd_a = number / 10.0;
e = floor((modf(itd_a,&itd_b)* 10)+0.5);
itd_a = itd_b / 10.0;
d = floor((modf(itd_a,&itd_b)* 10)+0.5);
itd_a = itd_b / 10.0;
c = floor((modf(itd_a,&itd_b)* 10)+0.5);
itd_a = itd_b / 10.0;
b = floor((modf(itd_a,&itd_b)* 10)+0.5);
itd_a = itd_b / 10.0;
a = floor((modf(itd_a,&itd_b)* 10)+0.5);
}

 clk() interrupt 3  //timer 1 interrupt
{
clk_tmp++;
clk_tmp2++;
if (clk_tmp2 > (1236)){ // update display
clk_tmp2 = 0;
rps_avg = floor(((rps_his[0] + rps_his[1] + rps_his[2] + rps_his[3] + rps_his[4])/5)*60);
line_1();
int_to_digits(rps_avg);
// to lcd: AVG:
lcd_send (65);
lcd_send (86);
lcd_send (71);
lcd_send (58);
lcd_send_num(a);
lcd_send_num(b);
lcd_send_num(c);
lcd_send_num(d);
lcd_send_num(e);
// to lcd:  rpm
lcd_send (32);
lcd_send (114);
lcd_send (112);
lcd_send (109);

if (P2_0 == 0){
	if (ani == 0){
	ani = 1;
	lcd_send (32);
	lcd_send (32);
	lcd_send (32);
	}else if(ani == 1){
	ani = 2;
	lcd_send (46);
	lcd_send (32);
	lcd_send (32);
	}else if(ani == 2){
	ani = 3;
	lcd_send (46);
	lcd_send (111);
	lcd_send (32);
	}else if(ani == 3){
	ani = 0;
	lcd_send (46);
	lcd_send (111);
	lcd_send (79);;
	} 
}else{
lcd_send (32);
lcd_send (32);
lcd_send (88);
}
rps_max = rps_his[0];
if (rps_his[1] > rps_max){
rps_max = rps_his[1];
}
if(rps_his[2] > rps_max){
rps_max = rps_his[2];
}
if(rps_his[4] > rps_max){
rps_max = rps_his[3];
}
if(rps_his[4] > rps_max){
rps_max = rps_his[4];
}
int_to_digits(rps_max*60);
line_2();
// to lcd: MAX:
lcd_send (77);
lcd_send (65);
lcd_send (88);
lcd_send (58);
lcd_send_num(a);
lcd_send_num(b);
lcd_send_num(c);
lcd_send_num(d);
lcd_send_num(e);
// to lcd:  rpm
lcd_send (32);
lcd_send (114);
lcd_send (112);
lcd_send (109);
lcd_send (32);
lcd_send (32);
lcd_send (32);
}
if (clk_tmp > (6584/scale)){ // update data
	clk_tmp = 0;
	if (P2_0 == 0){
			rps = TL0;
			temp = TH0;
			temp = temp * 256;
			rps = (rps + temp)* scale;
			rps_his[4] = rps_his[3];
			rps_his[3] = rps_his[2];
			rps_his[2] = rps_his[1];
			rps_his[1] = rps_his[0];
			rps_his[0] = rps;
	}
	TL0 = 0;
	TH0 = 0;
}
}
 count_pulses() interrupt 1  //counter 0 interrupt
{
if (scale < 10)
scale++;
//ex_pulses++;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void main(){
scale = 10 ;
P3_3 = 0; // ini proximity sensor, OFF
P3_4 = 1; // ini sensor input
P1_1 = 0; //turn LCD backlight ON
P2_0 = 1; //ini count/hold button
ini_lcd(); // ini the LCD
lcd_send_slow (32);
lcd_send_slow (32);
lcd_send_slow (32);
lcd_send_slow (32);
lcd_send_slow (32);
lcd_send_slow (68);
lcd_send_slow (45);
lcd_send_slow (84);
lcd_send_slow (65);
lcd_send_slow (67);
lcd_send_slow (72);
lcd_send_slow (32);
lcd_send_slow (32);
lcd_send_slow (32);
lcd_send_slow (32);
lcd_send_slow (32);
delay(30000);
delay(30000);
delay(30000);
delay(30000);
line_2();
lcd_send_slow (105);
lcd_send_slow (107);
lcd_send_slow (97);
lcd_send_slow (64);
lcd_send_slow (105);
lcd_send_slow (107);
lcd_send_slow (97);
lcd_send_slow (108);
lcd_send_slow (111);
lcd_send_slow (103);
lcd_send_slow (105);
lcd_send_slow (99);
lcd_send_slow (46);
lcd_send_slow (99);
lcd_send_slow (111);
lcd_send_slow (109);
delay(30000);
delay(30000);
delay(30000);
delay(30000);
delay(30000);
delay(30000);
delay(30000);
delay(30000);
delay(30000);
setup_interrupts();
while(1){
 P3_3 = ~P2_0;
 if (P2_0 == 1){
  scale= 4;
 }
//e = fmod(5,10);
}
}