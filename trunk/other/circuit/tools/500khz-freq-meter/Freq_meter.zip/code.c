// Frequency meter source code
// � Copyright 2006 Ibrahim Kamal. All Rights Reserved. 
// www.ikalogic.com

#include <REGX52.h> 
#include <math.h>
						
unsigned int temp,calc_del;
unsigned char a,b,c,d,e,dcnt;
float sample[5];
unsigned char scale = 9;
unsigned char dig[4],ord[4],pt[4];
unsigned long f,idl;
unsigned char bcd[10];
bit sleep = 0;
delay(y){
unsigned int i;
	for(i=0;i<y;i++){;}
}

setup_interrupts(){
EA = 1;
EX0 = 0;
EX1 = 0;
ET0 = 1; //Enable the Timer/counter 0 interrupt
TR0 = 1; //Enable Timer/counter 0 to count
TMOD = 0X25;  //counter 0 in mode 1 (16 bit counter)  , timer 1 in mode 2 (auto reload from TH1
TL0 = 0; //empty the counting registers
TH0	= 0; //empty the counting registers
TH1 = 100; //start timer 1 from 0
ET1 = 1; //enable timer 1 interrrupt
TR1 = 1; //Enable Timer/counter 1 to count
PT0 = 1;
PT1 = 0;
}

void int_to_digits(unsigned long number){ //store the digits of an integer number in the variable a,b,c,d
float itd_a,itd_b;
itd_a = itd_a = number / 10.0;
dig[3] = floor((modf(itd_a,&itd_b)* 10)+0.5);
itd_a = itd_b / 10.0;
dig[2] = floor((modf(itd_a,&itd_b)* 10)+0.5);
itd_a = itd_b / 10.0;
dig[1] = floor((modf(itd_a,&itd_b)* 10)+0.5);
itd_a = itd_b / 10.0;
dig[0] = floor((modf(itd_a,&itd_b)* 10)+0.5);
}

 count_pulses() interrupt 1  //counter 0 interrupt
{
if (scale < 200)
scale++;
//ex_pulses++;
}
calc_and_disp() interrupt 3 {
		if (sleep != 1){
		P0 = (bcd[dig[3-dcnt]] - pt[3-dcnt]) ;
		P1 = ord[3-dcnt];
		dcnt++;
		if(dcnt > 3){
		dcnt = 0;
		}
		}


}


void main (){
  	setup_interrupts();	
	P3_4 = 1;
	P3_7 = 0;
	P0 = 0;
	P1 = 1;
	bcd[0] = 136;
	bcd[1] = 190;
	bcd[2] = 196;
	bcd[3] = 148;
	bcd[4] = 178;
	bcd[5] = 145;
	bcd[6] = 129;
	bcd[7] = 184;
	bcd[8] = 128;
	bcd[9] = 144;
	ord[0] = 1;
	ord[1] = 2;
	ord[2] = 4;
	ord[3] = 8;
	dcnt = 0;
while(1){
	calc_del++;
	if (calc_del > ((2248/scale))){ // update data
	calc_del = 0;
	f = (TL0 + (TH0* 256));
	sample[4] = sample[3];
	sample[3] = sample[2];
	sample[2] = sample[1];
	sample[1] = sample[0];
	sample[0] = f;
	TL0 = 0;
	TH0 = 0;
	if (TH0 < 10){
	 if (scale > 9){
	  scale--;
	 }
	}
	
	// calculate F to display
	f = floor((sample[0] + sample[1] + sample[2]+ sample[3]+ sample[4])/5)*scale;
	if (f < 1000){
	pt[0] = 128;
	pt[1] = 0;
	pt[2] = 0;
	pt[3] = 0;
	}else if ((f > 999) & (f < 10000)){
	f = f / 1;
	pt[0] = 128;
	pt[1] = 0;
	pt[2] = 0;
	pt[3] = 0;
	}else if ((f > 9999) & (f < 100000)){
	f = f / 10;
	pt[0] = 0;
	pt[1] = 128;
	pt[2] = 0;
	pt[3] = 0;
	}else if ((f > 99999) & (f < 1000000)){
	f = f / 100;
	pt[0] = 0;
	pt[1] = 0;
	pt[2] = 128;
	pt[3] = 0;
	}else if ((f > 999999)){
	f = f / 1000;
	pt[0] = 0;
	pt[1] = 0;
	pt[2] = 0;
	pt[3] = 128;
	}
	int_to_digits(f);
	
	//goto sleep or shutdown
	if (f == 0){
	idl++;
	}else{
	idl = 0;
	sleep = 0;
	}
	if (idl > 399){
		sleep = 1;
		P0 = 127;
		P1 = ord[3-dcnt];
		dcnt++;
		if(dcnt > 3){
			dcnt = 0;
		}
	}
	if (idl > 999){ //power down
	P3_7 = 1;
	P1 = 0;
	P0 = 0;
	PCON = 1;
	}		
	}  

}
}
