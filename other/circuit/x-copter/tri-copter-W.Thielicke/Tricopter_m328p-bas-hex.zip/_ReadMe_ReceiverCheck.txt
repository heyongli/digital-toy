You can test your serial connection and the input from the receiver when you flash "Tricopter_ReceiverCheck.hex" to the arduino.

You can get a terminal program here:
http://www.compuphase.com/software/termite23.zip
http://www.compuphase.com/software_termite.htm

Open a terminal window (select the correct COM port and set baud rate to 38400) and connect the battery (always dismount the motors or the propellers for safety reasons).

The LEDs should turn on and off after a short moment. The green LED on the Arduino should flash relatively fast.

If the green LED on the Arduino flashes but you don't see anything in the terminal, most likely your serial port connection doesn't work.

Shrediquette now displays the signals from the receiver in the terminal window. Channels 1 to 5 are displayed, although you should always make sure that at least 6 channels are fed to the controllerboard. This is needed for synchronization.

All values should range from about -37 to about +37. When the sticks are centered, they should be zero. If it isn't like that, change the settings in your transmitter. Have a look at channel 5: This is your switch for starting the motors and setting the flight mode. It should be around: 
-30 for switching the motors off
0 for selecting acro mode
+30 for selecting hover mode

Example:

ch1: -37 ch2: 0 ch3: 1 ch4: -1 ch5: -30


If everything works, you can flash the tricopter firmware to the controller and set the parameters via the GUI.