/******************************************************************************
  SH1_Clock.c   A text LCD clock using the Shift1-LCD kit module
  (requires;) #include "Shift1_LCD.c"
  Open-source  -  2nd Nov 2009  -  www.RomanBlack.com

  This is a basic clock/timer 12:00:00 that can be used as is
  (as a clock) or adapted to count up or down for timing and
  control tasks etc.

  The 1 second period is generated from a constant 8000000 (for 8MHz xtal)
  which is at full resolution, so it can be adjusted to "trim" the clock
  to give a very high accuracy.

  To adjust clock (using the ONE button);
  * Hold button, keep it held; to change HOURS
  * Quick presses of button; changes MINUTES (and resets SECONDS)

******************************************************************************/


// global vars
unsigned char hours;
unsigned char mins;
unsigned char secs;

unsigned char new_second; // is 1 after new second is reached
unsigned long period;     // used to generate 1 second periods

unsigned char debounce;   // for button clock updating

#define XTALHz 8000000    // 8 Mhz. (can trim this to fine-tune clock speed)

#define PIN_BUT_ADJUST  GPIO.F1    // low = pressed

//-----------------------------------------------------------------------------
// this line adds my routines for Shift1 LCD driving
#include "Shift1_LCD.c"
//-----------------------------------------------------------------------------


//=============================================================================
//   POLL TIMER
//=============================================================================
void poll_timer(void)
{
  //-----------------------------------------------------
  // this function must be called often, don't allow more
  // than 131 mS between calls.
  // 8Mhz; TMR1 1:4 prescale overflows every 7.6Hz (131mS)
  // (if 20Mhz TMR1 1:4 prescale overflows every 19Hz (53mS))
  //  
  // TMR1 is at 1:4 prescaler, so 1 second = xtal Mhz / 16.
  //-----------------------------------------------------
  // if TMR1 overflowed, check if 1 second has passed
  if(PIR1.TMR1IF)  
  {
    // clear overflow flag
    PIR1.TMR1IF = 0;
    // add another overflow period to total
    period += 65536;
    // test if reached 1 second yet...
    if(period >= (XTALHz / 16))
    {  
      period -= (XTALHz / 16);
      new_second = 1;
    }
  }
}
//-----------------------------------------------------------------------------


//=============================================================================
//   UPDATE CLOCK
//=============================================================================
void update_clock(void)
{
  //-----------------------------------------------------
  // this updates the clock values every new second
  // note! secs is incremented in main()
  if(secs >= 60)
  {
    secs = 0;
    mins++;  
  }  
  if(mins >= 60)
  {
    mins = 0;
    hours++;  
  }  
  if(hours > 12)    // for 12:00:00 - (12 hour) clock
  {
    hours = 1;
  }  
  //if(hours > 23)    // for 00:00:00 - (24 hour) clock
  //{
  //  hours = 0;
  //}  
}
//-----------------------------------------------------------------------------


//=============================================================================
//   DISPLAY CLOCK
//=============================================================================
void display_clock(void)
{
  //-----------------------------------------------------
  // display the clock values to the LCD
    
  // move to home position
  SH1_Lcd_Move(0,0);    // position on 2x16 display
  
  // show hours
  SH1_Lcd_Char('0' + (hours / 10));
  SH1_Lcd_Char('0' + (hours % 10));
  SH1_Lcd_Char(':');
  poll_timer();

  // show mins
  SH1_Lcd_Char('0' + (mins / 10));
  SH1_Lcd_Char('0' + (mins % 10));
  SH1_Lcd_Char(':');
  poll_timer();

  // show secs
  SH1_Lcd_Char('0' + (secs / 10));
  SH1_Lcd_Char('0' + (secs % 10));
}
//-----------------------------------------------------------------------------


// wrap this delay in a function to save ROM
void Delay_mS_400(void)
{
   Delay_mS(400);
}

//=============================================================================
//   MAIN
//=============================================================================
void main ()
{
  //-----------------------------------------------------
  // PIC 12F675  setup ports

  ANSEL = 0;
  CMCON = 0x07;

  GPIO =   0b00000100;  // GP2 high default for Shift1 out
  TRISIO = 0b00000010;  // GP2 is Shift1 out, GP1 is button
  WPU =    0b00001010;  // pin pullups; 1 = pullup on (for button)

  //-----------------------------------------------------
  // setup timer
  T1CON = 0b00100001;
  
  // setup vars
  period = 0;
  new_second = 0;
  debounce = 0;

  hours = 12;   // starting clock values
  mins = 0;
  secs = 0;

  //-----------------------------------------------------
  // initialise LCD
  Delay_mS_400();
  SH1_Lcd_Init();           // init LCD
  SH1_lcd_backlight = 0;    // Shift1-LCD backlight OFF

  SH1_Lcd_Out(0,0,"SH1Clock");   // start message (optional)
  Delay_mS_400();
  
  //-----------------------------------------------------

  // main run loop here
  while(1)
  {
    //-------------------------------------
    // 12mS per loop
    SH1_Delay_6mS();  // use existing delay to save ROM
    SH1_Delay_6mS();

    // always poll the timer
    poll_timer();  
  
    //-------------------------------------
    // update clock if 1 second was reached
    if(new_second)
    {
      new_second = 0;
      secs++;
      update_clock();     // format clock values
      display_clock();    // display to LCD
    }

    // CLOCK ADJUST button (lo = pressed)
    if(!PIN_BUT_ADJUST)
    {
      debounce++;
      
      // check for button HELD DOWN (adjust hours)
      if(debounce > 90)   // 90 is about 1.1 seconds
      {
        hours++;
        secs = 0;
        update_clock();     // format clock values
        display_clock();    // display to LCD
        debounce = 45;      // faster inc for next hour
      }
    }
    else   // else button is NOT pressed
    {
      // check for QUICK buttons press (adjust mins)
      if(debounce > 0 && debounce < 45)
      {
        mins++;
        secs = 0;
        update_clock();     // format clock values
        display_clock();    // display to LCD
      }
      debounce = 0;
    }
  }
}
//-----------------------------------------------------------------------------





