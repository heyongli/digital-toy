// � Copyright 2006 Ibrahim Kamal. All Rights Reserved. 
// www.ikalogic.com

#include <REGX51.h> 
#include <math.h>
unsigned char ir;
bit ir1,ir2;

delay(y){
unsigned int i;
	for(i=0;i<y;i++){;}
}


void main(){
//P2.0 IR control
//P2.1 IR input
while(1){

P2_0 = 1; //send IR
delay(20);
ir1 = P2_1;
P2_0 = 0;  //stop IR
delay(98);
ir2 = P2_1; 
if ((ir1 == 1)&(ir2 == 0)){
	ir = 1;
}else{
	ir = 0;
}

P2_3 = ir;

}
}